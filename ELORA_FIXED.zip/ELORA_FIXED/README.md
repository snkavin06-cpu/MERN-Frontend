# ELORA Cosmetics React Website

## Run in VS Code
1. Extract this ZIP folder.
2. Open the extracted `ELORA_FIXED` folder in VS Code (File > Open Folder).
3. Open Terminal > New Terminal.
4. Run `npm install`
5. Run `npm run dev`
6. Open the localhost address shown in the terminal (usually http://localhost:5173).

Important: Do not open `index.html` by double-clicking. Run the Vite development server using `npm run dev`.

## Features
Home, shop/products, category pages, product details, shopping bag, sign in, register, forgot password, about, contact, FAQ, terms and privacy pages. Cart and demo account data use browser localStorage. Checkout is a demo only; no real payment is collected.
